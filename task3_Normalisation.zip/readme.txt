1. 加3次git提交；
2. 加ID和NAME。
3. 修改文件为：task3-show.md
